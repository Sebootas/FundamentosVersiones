package com.Sebotas.guisba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn: Button = findViewById(R.id.backBTN)
        btn.setOnClickListener{
            val intent: Intent = Intent(this, FirstScreen:: class.java)
            startActivity(intent)
        }

        val btn2: Button = findViewById(R.id.signupbtn)
        btn2.setOnClickListener{
            val username = findViewById<EditText>(R.id.username)
            val email = findViewById<EditText>(R.id.email)
            val password = findViewById<EditText>(R.id.password)
            val repassword = findViewById<EditText>(R.id.repassword)

            if (username.text.toString().trim().equals("")||email.text.toString().trim().equals("")
                ||password.text.toString().trim().equals("")||repassword.text.toString().trim().equals("")){
                Toast.makeText(applicationContext, "Missing Sign Up information", Toast.LENGTH_LONG).show()
            }
            else if (!repassword.getText().toString().equals(password.getText().toString())){
                Toast.makeText(applicationContext, "Passwords do not match", Toast.LENGTH_LONG).show()
            }
            else{
                val intent: Intent = Intent(this, Home:: class.java)
                startActivity(intent)
            }


        }
    }
}
package com.Sebotas.guisba

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LogIn : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

        val btn: Button = findViewById(R.id.backBTN)
        btn.setOnClickListener{
            val intent: Intent = Intent(this, FirstScreen:: class.java)
            startActivity(intent)
        }

        val btn2: Button = findViewById(R.id.start)
        btn2.setOnClickListener {
            val userName = findViewById<EditText>(R.id.username)
            val email = findViewById<EditText>(R.id.email)
            val password = findViewById<EditText>(R.id.password)
            if (userName.text.toString().trim().equals("")||email.text.toString().trim().equals("")
                ||password.text.toString().trim().equals("")) {
                Toast.makeText(applicationContext, "Missing Log in information", Toast.LENGTH_LONG).show()
            }
            else{
                val intent: Intent = Intent(this, Home::class.java)
                startActivity(intent)
            }


        }

    }

}